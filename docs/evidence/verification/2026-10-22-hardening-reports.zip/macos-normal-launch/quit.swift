import AppKit
let pid = pid_t(CommandLine.arguments[1])!
if let app = NSRunningApplication(processIdentifier: pid) { print(app.terminate()) } else { print("process missing") }
