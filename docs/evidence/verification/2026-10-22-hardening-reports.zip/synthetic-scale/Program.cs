using System.Diagnostics;
using System.Text.Json;
using Synups.Core.Monitoring;
using Synups.Core.Persistence;
var path=Path.GetFullPath(args[1]); var count=int.Parse(args[2]);
if(args[0]=="seed") {
 await using var store=new SqliteHistoryStore(path); await store.LoadAsync();
 var utc=new DateTimeOffset(2026,10,20,12,0,0,TimeSpan.Zero); var sid=Guid.NewGuid();
 var session=new SessionRecord(sid,utc,utc.AddDays(1),utc.AddDays(1),TimeSpan.FromDays(1),false,false);
 for(var start=0;start<count;start+=500) {
 var rows=Enumerable.Range(start,Math.Min(500,count-start)).Select(i=>new OutageRecord(Guid.NewGuid(),sid,Guid.NewGuid(),"Synthetic scale fixture "+i,utc.AddSeconds(i),utc.AddSeconds(i-1),utc.AddSeconds(i+1),null,TimeSpan.FromSeconds(1),false,null,"Test-only fixture, never real measurement")).ToArray();
 await store.CommitAsync(new(rows,[],session)); }
 Console.WriteLine("SEEDED_TEST_ONLY="+count); return;
}
GC.Collect(); var before=GC.GetTotalMemory(true);var allocated=GC.GetTotalAllocatedBytes(true);var sw=Stopwatch.StartNew();
await using var reader=new SqliteHistoryStore(path);var state=await reader.LoadAsync();var initialMs=sw.Elapsed.TotalMilliseconds;var retained=GC.GetTotalMemory(true)-before;
var page=await reader.ReadIncidentPageAsync(new(50));var rowsRead=0;long? cursor=null;long? upper=null;
do { var next=await reader.ReadIncidentPageAsync(new(100,cursor,UpperBound:upper));upper=next.UpperBound;cursor=next.NextCursor;rowsRead+=next.Items.Count; }while(cursor is not null);
Console.WriteLine(JsonSerializer.Serialize(new {synthetic_fixture=true,source_revision="6446990",fixture_rows=count,cached_incidents=state.Outages.Count,page_size=page.Items.Count,streamed_rows=rowsRead,database_bytes=new FileInfo(path).Length,startup_milliseconds=initialMs,retained_managed_bytes_after_initial_load=retained,total_allocated_bytes_all_pages=GC.GetTotalAllocatedBytes(true)-allocated,total_milliseconds=sw.Elapsed.TotalMilliseconds,working_set_bytes=Process.GetCurrentProcess().WorkingSet64,note="Separate fresh reader process after fixture seeding; no endurance or production outage claim"}));
