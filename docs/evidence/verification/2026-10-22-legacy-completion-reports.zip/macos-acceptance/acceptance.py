import hashlib,json,os,sqlite3,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
root=Path('artifacts/parity-completion/macos-acceptance').resolve();root.mkdir(exist_ok=True);app=Path('artifacts/parity-completion/inspected-7ca85cc/osx-arm64/package-unpacked/Synups-osx-arm64/Synups.app').resolve();exe=app/'Contents/MacOS/Synups';data=root/'normal-profile';assert not data.exists();record={'started_utc':datetime.now(timezone.utc).isoformat(),'candidate':'0.1.1-rc.3','source_revision':'7ca85cccce6e3609d08d64e4f23172fa14fffb25','apphost_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'normal_launch_without_installation_check':True,'physical_interaction_verified':False}
result=subprocess.run(['open','-n',str(app),'--args','--data-directory',str(data)],capture_output=True,text=True);record['launchservices_exit_code']=result.returncode;assert result.returncode==0
pid=None
for _ in range(100):
 lines=subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines()
 matches=[int(line.strip().split(None,1)[0]) for line in lines if line.strip().split(None,1)[-1].startswith(str(exe)+' --data-directory '+str(data))]
 if matches:pid=matches[0];break
 time.sleep(.1)
assert pid;record['process_id']=pid
try:
 time.sleep(2)
 r=subprocess.run(['swift',str(root/'windows.swift'),str(pid)],capture_output=True,text=True,timeout=45);assert r.returncode==0,r.stderr;windows=json.loads(r.stdout);assert windows;record['owned_on_screen_windows']=windows
 accessibility=subprocess.run(['osascript','-e','tell application "System Events" to get UI elements enabled'],capture_output=True,text=True,timeout=10);record['accessibility_permission']=accessibility.stdout.strip()
 if accessibility.stdout.strip()!='true':record['blocked_interactions']=['physical tray Show/Exit','keyboard Tab/Shift+Tab/Enter/Space/Escape','native CSV save dialog','physical minimize/restore','physical close while monitoring/pending storage','physical resize/readability review']
 capture=subprocess.run(['screencapture','-x','-l',str(windows[0]['kCGWindowNumber']),str(root/'normal-window.png')],capture_output=True,text=True,timeout=15);record['os_window_capture_exit_code']=capture.returncode;record['os_window_capture_error']=capture.stderr.strip()
 quit_result=subprocess.run(['swift',str(root/'quit.swift'),str(pid)],capture_output=True,text=True,timeout=45);record['native_quit_request']=quit_result.stdout.strip()
 for _ in range(100):
  try:os.kill(pid,0)
  except ProcessLookupError:break
  time.sleep(.1)
 else:raise RuntimeError('Native quit did not complete')
 record['owned_process_exited_after_native_quit']=True;record['application_exit_code']='Not observable through LaunchServices; not claimed as0'
 with sqlite3.connect('file:'+str(data/'history.v1.db')+'?mode=ro',uri=True) as db:record['sessions_on_passive_normal_launch']=db.execute('select count(*) from sessions').fetchone()[0];assert record['sessions_on_passive_normal_launch']==0
finally:
 try:os.kill(pid,0)
 except ProcessLookupError:pass
 else:os.kill(pid,15);record['forced_owned_cleanup']=True
 record['finished_utc']=datetime.now(timezone.utc).isoformat();(root/'normal-acceptance.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
