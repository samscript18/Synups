using System.Security.Cryptography;
using System.Text.Json;
using Synups.Core.Persistence;
using Synups.Core.Monitoring;
var root=Path.GetFullPath(args[0]);
var names=new[]{"history.v1.db","configuration.v1.json","preferences.v1.json"};
string Hash(string name)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(root,name)))).ToLowerInvariant();
var before=names.ToDictionary(n=>n,Hash);
await using(var store=new SqliteHistoryStore(Path.Combine(root,"history.v1.db"))) {
 var history=await store.LoadAsync(true);if(history.Sessions.Count<1)throw new Exception("Prior sessions missing");
 var profile=await new ConfigurationStore(Path.Combine(root,"configuration.v1.json")).LoadAsync();if(profile.NeedsRecovery)throw new Exception("Original config unreadable");
 var prefs=await new PreferencesStore(Path.Combine(root,"preferences.v1.json")).LoadAsync();if(prefs.Error is not null||prefs.Preferences.DateLogFilenames)throw new Exception("Old preferences incompatible");
 Console.WriteLine(JsonSerializer.Serialize(new {source_revision="7ca85cccce6e3609d08d64e4f23172fa14fffb25",baseline_revision="6446990571c285b5c2e2a4bb293cbd8e3af40171",sessions=history.Sessions.Count,interrupted=history.Sessions.Count(s=>s.Interrupted),outages=history.Outages.Count,event_ids=history.Events.Select(e=>e.Id),group_ids=profile.Configuration!.Groups.Select(g=>g.Id),target_ids=profile.Configuration.Groups.SelectMany(g=>g.Targets).Select(t=>t.Id),old_preferences_loaded=true,date_filename_default=false}));
}
var after=names.ToDictionary(n=>n,Hash);foreach(var n in names.Where(n=>n!="history.v1.db"))if(before[n]!=after[n])throw new Exception("Upgrade read changed "+n);
Console.WriteLine(JsonSerializer.Serialize(new{configuration_and_preferences_byte_identical=true,database_header_may_change=true,before,after}));
